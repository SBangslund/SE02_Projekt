create function adduseradress(roadname character varying, country character varying, postcode character varying, city integer, housenumber character varying, level character varying, userid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO useraddress VALUES (roadname, country, postcode, city, housenumber, level, userid);
END;
$$;

alter function adduseradress(varchar, varchar, varchar, integer, varchar, varchar, varchar) owner to kzpurfgw;

