create function getuserid(username_varchar character varying, password_varchar character varying) returns character varying
  language plpgsql
as
$$
DECLARE
  usernameBoolean BOOLEAN;
  passwordBoolean BOOLEAN;
BEGIN
  usernameBoolean := 1 <= (
    SELECT count(username)
    FROM logininfo
    WHERE username = userName_varchar);

  passwordBoolean := 1 <= (
    SELECT count(username)
    FROM logininfo
    WHERE username = userName_varchar AND password = password_varchar);

  IF usernameBoolean = TRUE 
    THEN IF passwordBoolean = TRUE 
      THEN RETURN (
        SELECT userid 
        FROM logininfo 
        WHERE username = userName_varchar AND password = password_varchar
        );
    ELSE 
        RETURN 'Password is not correct';
    END IF ;
  ELSE
    RETURN 'Username not found';
  END IF;
END;
$$;

alter function getuserid(varchar, varchar) owner to kzpurfgw;

