create function getuserinfo(userid_input character varying) returns TABLE(mail character varying, firstname character varying, lastname character varying, phone character varying, picture character varying, userid character varying, institutionsid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT (mail, firstname, lastname, CAST(phone AS VARCHAR), cast(picture AS varchar), userid, institutionsid)
    FROM userinfo
    WHERE userid_input = userid;
END;
$$;

alter function getuserinfo(varchar) owner to kzpurfgw;

