create function getuseraddress(userid_input character varying) returns TABLE(roadname character varying, country character varying, postcode character varying, city character varying, housenumber character varying, level character varying, userid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT (roadname, country, CAST(postcode AS VARCHAR), city, cast(housenumber AS varchar), level, userid)
    FROM useraddress
    WHERE userid_input = userid;
END;
$$;

alter function getuseraddress(varchar) owner to kzpurfgw;

