create function add_activity(name character varying, type character varying, date character varying, starttime integer, endtime character varying, activityid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO activities VALUES (CAST(name AS VARCHAR),
                               CAST(type AS VARCHAR),
                               to_date(date, 'DD/Mon/YYYY'),
                               CAST(starttime AS VARCHAR),
                               CAST(endtime AS VARCHAR),
                               CAST(activityid AS VARCHAR));
END;
$$;

alter function add_activity(varchar, varchar, varchar, integer, varchar, varchar) owner to kzpurfgw;

