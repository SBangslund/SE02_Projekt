create function get_activity(activityid_input character varying) returns TABLE(name_output character varying, type character varying, date character varying, starttime character varying, endtime character varying, activityid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT activities.name,
           activities.type,
           CAST(activities.date AS VARCHAR),
           activities.starttime,
           activities.endtime,
           activities.activityid
    FROM activities
    WHERE activityid_input = activities.activityid;
END;
$$;

alter function get_activity(varchar) owner to kzpurfgw;

