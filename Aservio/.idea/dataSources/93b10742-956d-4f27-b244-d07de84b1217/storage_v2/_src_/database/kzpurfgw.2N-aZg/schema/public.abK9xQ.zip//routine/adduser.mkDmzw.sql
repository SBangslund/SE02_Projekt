create function adduser(username character varying, password character varying, userid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO logininfo VALUES (username, password, userid);
END;
$$;

alter function adduser(varchar, varchar, varchar) owner to kzpurfgw;

