create function getuserinfo(userid_input character varying) returns TABLE(mail_output character varying, firstname_output character varying, lastname_output character varying, phone_output character varying, picture_output character varying, userid_output character varying, institutionname_output character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT userinfo.mail, userinfo.firstname, userinfo.lastname, cast(userinfo.phone as VARCHAR), cast('null' as varchar), userinfo.userid, userinfo.institutionname
    FROM userinfo
    WHERE userid_input = userinfo.userid;
END;
$$;

alter function getuserinfo(varchar) owner to kzpurfgw;

