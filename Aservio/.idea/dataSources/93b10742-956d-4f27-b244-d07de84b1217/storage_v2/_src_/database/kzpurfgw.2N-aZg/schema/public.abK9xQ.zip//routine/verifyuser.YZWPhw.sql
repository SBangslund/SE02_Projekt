create function verifyuser(username_varchar character varying, password_varchar character varying) returns character varying
  language plpgsql
as
$$
DECLARE
  usernameBoolean BOOLEAN;
  passwordBoolean BOOLEAN;
BEGIN
  usernameBoolean := 1 = (
    SELECT count(username)
    FROM logininfo
    WHERE username = userName_varchar);

  passwordBoolean := 1 = (
    SELECT count(username)
    FROM logininfo
    WHERE username = userName_varchar AND password = password_varchar);

  IF usernameBoolean = TRUE
  THEN IF passwordBoolean = TRUE
  THEN RETURN 'true';
  ELSE
    RETURN 'false, wrong password';
  END IF ;
  ELSE
    RETURN 'false, wrong username';
  END IF;
END;
$$;

alter function verifyuser(varchar, varchar) owner to kzpurfgw;

