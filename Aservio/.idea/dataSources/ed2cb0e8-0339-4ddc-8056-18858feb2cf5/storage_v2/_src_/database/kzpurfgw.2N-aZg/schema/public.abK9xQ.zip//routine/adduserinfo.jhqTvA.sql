create function adduserinfo(mail character varying, firstname character varying, lastname character varying, phone integer, picture character varying, userid character varying, institutionid integer) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO userinfo VALUES (CAST(mail AS VARCHAR),
                               CAST(firstname AS VARCHAR),
                               CAST(lastname AS VARCHAR),
                               CAST(phone AS INTEGER),
                               CAST(picture AS VARCHAR),
                               CAST(userid AS VARCHAR),
                               CAST(institutionid AS INT));
END;
$$;

alter function adduserinfo(varchar, varchar, varchar, integer, varchar, varchar, integer) owner to kzpurfgw;

