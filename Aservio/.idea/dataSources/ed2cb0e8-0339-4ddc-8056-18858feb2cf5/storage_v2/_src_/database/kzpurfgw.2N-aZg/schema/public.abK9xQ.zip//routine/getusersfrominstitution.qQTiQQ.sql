create function getusersfrominstitution(institutionid_input integer) returns TABLE(userid_output character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT DISTINCT userinfo.userid
    FROM userinfo NATURAL JOIN institution
    WHERE institutionid_input = userinfo.institutionid;
END;
$$;

alter function getusersfrominstitution(integer) owner to kzpurfgw;

