create function adduser(username character varying, password character varying, userid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO logininfo VALUES (CAST(username AS VARCHAR),
                                CAST(password AS VARCHAR),
                                CAST(userid AS VARCHAR));
END;
$$;

alter function adduser(varchar, varchar, varchar) owner to kzpurfgw;

