create function getuseraddress(userid_input character varying) returns TABLE(roadname character varying, country character varying, postcode character varying, city character varying, housenumber character varying, level character varying, userid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT useraddress.roadname,
           useraddress.country,
           Cast(useraddress.postcode AS varchar),
           useraddress.city,
           useraddress.housenumber,
           useraddress.level,
           useraddress.userid
    FROM useraddress
    WHERE userid_input = useraddress.userid;
END;
$$;

alter function getuseraddress(varchar) owner to kzpurfgw;

