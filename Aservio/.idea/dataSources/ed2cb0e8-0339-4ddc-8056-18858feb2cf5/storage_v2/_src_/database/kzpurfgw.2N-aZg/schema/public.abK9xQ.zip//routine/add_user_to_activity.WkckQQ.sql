create function add_user_to_activity(activityid character varying, userid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO activity_has_users VALUES (CAST(activityid AS VARCHAR),
                               CAST(userid AS VARCHAR));
END;
$$;

alter function add_user_to_activity(varchar, varchar) owner to kzpurfgw;

