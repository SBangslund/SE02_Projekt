create function get_notes_from_user(userid_input character varying) returns TABLE(noteid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT noteHasUser.noteid
    FROM noteHasUser
    WHERE userid_input = noteHasUser.userid;
END;
$$;

alter function get_notes_from_user(varchar) owner to kzpurfgw;

