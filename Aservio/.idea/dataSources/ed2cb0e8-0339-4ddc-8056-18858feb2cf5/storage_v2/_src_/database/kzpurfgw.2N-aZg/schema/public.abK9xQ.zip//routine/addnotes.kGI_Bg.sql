create function addnotes(id character varying, notedate character varying, starttime character varying, endtime character varying, notetext character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO notes VALUES (CAST(id AS VARCHAR),
                               notedate(date, 'DD/Mon/YYYY'),
                               CAST(starttime AS VARCHAR),
                               CAST(endtime AS VARCHAR),
                               CAST(notetext AS VARCHAR));
END;
$$;

alter function addnotes(varchar, varchar, varchar, varchar, varchar) owner to kzpurfgw;

