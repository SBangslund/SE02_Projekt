create function get_note(noteid_input character varying) returns TABLE(noteinfo character varying, notedate bigint, noteid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT Cast(notes.noteInfo AS VARCHAR),
           CAST(notes.noteDate AS BIGINT),
           CAST(notes.noteid AS VARCHAR)
    FROM notes
    WHERE noteid_input = notes.noteid;
END;
$$;

alter function get_note(varchar) owner to kzpurfgw;

