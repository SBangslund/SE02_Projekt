create function get_note(noteid_input character varying) returns TABLE(notetext character varying, notedate bigint, starttime character varying, endtime character varying, noteid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT Cast(notes.noteText AS VARCHAR),
           CAST(notes.noteDate AS BIGINT),
           notes.starttime,
           notes.endtime,
           CAST(notes.noteid AS VARCHAR)
    FROM notes
    WHERE noteid_input = notes.noteid;
END;
$$;

alter function get_note(varchar) owner to kzpurfgw;

