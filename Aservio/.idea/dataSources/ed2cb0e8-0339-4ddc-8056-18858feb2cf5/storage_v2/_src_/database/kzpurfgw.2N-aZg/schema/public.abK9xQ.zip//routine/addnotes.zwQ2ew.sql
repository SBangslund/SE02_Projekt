create function addnotes(id character varying, notedate date, starttime character varying, endtime character varying, notetext character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO notes VALUES (CAST(id AS VARCHAR),
                               notedate(date, 'DD/Mon/YYYY'),
                               CAST(starttime AS VARCHAR),
                               CAST(endtime AS VARCHAR),
                               CAST(notetext AS VARCHAR));
END;
$$;

alter function addnotes(varchar, date, varchar, varchar, varchar) owner to kzpurfgw;

