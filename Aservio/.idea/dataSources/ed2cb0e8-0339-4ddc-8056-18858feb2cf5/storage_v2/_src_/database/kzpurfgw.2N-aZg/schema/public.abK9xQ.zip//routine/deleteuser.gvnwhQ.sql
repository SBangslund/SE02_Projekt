create function deleteuser(userid_input character varying) returns void
  language plpgsql
as
$$
BEGIN
  DELETE FROM logininfo
  WHERE logininfo.userid = userid_input;
  DELETE FROM activity_has_users
  WHERE activity_has_users.userid = userid_input;
  DELETE FROM userinfo
  WHERE userinfo.userid = userid_input;
  DELETE FROM useraddress
  WHERE useraddress.userid = userid_input;
  DELETE FROM notehasuser
  WHERE notehasuser.userid = userid_input;
END;
$$;

alter function deleteuser(varchar) owner to kzpurfgw;

