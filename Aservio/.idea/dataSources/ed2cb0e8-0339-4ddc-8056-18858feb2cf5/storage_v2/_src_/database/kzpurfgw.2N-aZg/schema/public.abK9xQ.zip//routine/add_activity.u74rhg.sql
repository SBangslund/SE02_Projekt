create function add_activity(name character varying, type character varying, starttime bigint, endtime bigint, activityid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO activities VALUES (CAST(name AS VARCHAR),
                                 CAST(type AS VARCHAR),
                                 CAST(starttime AS BIGINT),
                                 CAST(endtime AS BIGINT),
                                 CAST(activityid AS VARCHAR));
END;
$$;

alter function add_activity(varchar, varchar, bigint, bigint, varchar) owner to kzpurfgw;

