create function add_activity(name character varying, type character varying, starttime date, endtime date, activityid character varying, description character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO activities VALUES (CAST(name AS VARCHAR),
                                 CAST(type AS VARCHAR),
                                 endtime,
                                 endtime,
                                 CAST(activityid AS VARCHAR),
                                 CAST(description AS VARCHAR));
END;
$$;

alter function add_activity(varchar, varchar, date, date, varchar, varchar) owner to kzpurfgw;

