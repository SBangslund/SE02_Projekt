create function get_users_from_activity(activity_id character varying) returns TABLE(userid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT activity_has_users.userid
    FROM activity_has_users
    WHERE activity_id = activity_has_users.activityid;
END;
$$;

alter function get_users_from_activity(varchar) owner to kzpurfgw;

