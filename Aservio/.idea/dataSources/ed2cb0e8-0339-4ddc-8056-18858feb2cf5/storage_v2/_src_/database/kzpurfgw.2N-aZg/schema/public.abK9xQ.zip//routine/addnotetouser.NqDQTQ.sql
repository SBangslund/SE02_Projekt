create function addnotetouser(userid_input character varying, noteid_input character varying) returns void
  language plpgsql
as
$$
BEGIN
    INSERT INTO noteHasUser VALUES (
        userid_input,
        noteid_input
    );   
END;
$$;

alter function addnotetouser(varchar, varchar) owner to kzpurfgw;

