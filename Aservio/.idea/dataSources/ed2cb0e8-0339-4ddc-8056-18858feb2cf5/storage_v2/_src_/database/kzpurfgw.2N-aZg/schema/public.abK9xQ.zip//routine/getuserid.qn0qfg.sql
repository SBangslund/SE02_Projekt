create function getuserid(username_varchar character varying, password_varchar character varying, userid character varying) returns character varying
  language plpgsql
as
$$
DECLARE
    usernameBoolean boolean;
    passwordBoolean boolean;
begin
  usernameBoolean := 1 <= (
    select count(username)
    from logininfo
    where username = userName_varchar);

  IF usernameBoolean = true THEN return (
    select password from logininfo where userName_varchar = username
    );
    else return 'not found';
  END IF;
end;
$$;

alter function getuserid(varchar, varchar, varchar) owner to kzpurfgw;

