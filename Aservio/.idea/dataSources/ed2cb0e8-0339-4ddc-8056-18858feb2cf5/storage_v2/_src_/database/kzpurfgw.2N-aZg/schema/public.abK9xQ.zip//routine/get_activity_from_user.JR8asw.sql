create function get_activity_from_user(userid_input character varying) returns TABLE(activityid character varying)
  language plpgsql
as
$$
BEGIN
  RETURN QUERY
    SELECT activity_has_users.activityid
    FROM activity_has_users
    WHERE userid_input = activity_has_users.userid;
END;
$$;

alter function get_activity_from_user(varchar) owner to kzpurfgw;

