create function addnotes(notetext character varying, notedate bigint, starttime character varying, endtime character varying, noteid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO notes VALUES (CAST(notetext AS VARCHAR),
                               CAST(notedate AS BIGINT),
                               CAST(starttime AS VARCHAR),
                               CAST(endtime AS VARCHAR),
                               CAST(noteid AS VARCHAR));
END;
$$;

alter function addnotes(varchar, bigint, varchar, varchar, varchar) owner to kzpurfgw;

