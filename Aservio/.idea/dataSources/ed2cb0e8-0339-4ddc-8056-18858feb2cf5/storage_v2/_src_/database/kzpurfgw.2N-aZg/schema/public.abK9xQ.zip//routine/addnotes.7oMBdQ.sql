create function addnotes(noteinfo character varying, notedate bigint, noteid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO notes VALUES (CAST(noteInfo AS VARCHAR),
                               CAST(notedate AS BIGINT),
                               CAST(noteid AS VARCHAR));
END;
$$;

alter function addnotes(varchar, bigint, varchar) owner to kzpurfgw;

