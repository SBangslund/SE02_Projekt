create function deleteactivity(activityid_input character varying) returns void
  language plpgsql
as
$$
BEGIN
  DELETE FROM activities
  WHERE activities.activityid = activityid_input;
  DELETE FROM activity_has_users
  WHERE activity_has_users.activityid = activityid_input;
END;
$$;

alter function deleteactivity(varchar) owner to kzpurfgw;

