create function adduseraddress(roadname character varying, country character varying, postcode integer, city character varying, housenumber character varying, level character varying, userid character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO useraddress VALUES (CAST(roadname AS VARCHAR),
                                  CAST(country AS VARCHAR),
                                  CAST(postcode AS INTEGER),
                                  CAST(city AS VARCHAR),
                                  CAST(housenumber AS VARCHAR),
                                  CAST(level AS VARCHAR),
                                  CAST(userid AS VARCHAR));
END;
$$;

alter function adduseraddress(varchar, varchar, integer, varchar, varchar, varchar, varchar) owner to kzpurfgw;

