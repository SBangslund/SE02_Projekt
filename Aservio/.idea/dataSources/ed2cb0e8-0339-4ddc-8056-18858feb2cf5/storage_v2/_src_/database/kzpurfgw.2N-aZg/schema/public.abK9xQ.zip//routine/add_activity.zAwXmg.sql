create function add_activity(name character varying, type character varying, starttime bigint, endtime bigint, activityid character varying, description character varying) returns void
  language plpgsql
as
$$
BEGIN
  INSERT INTO activities VALUES (CAST(name AS VARCHAR),
                                 CAST(type AS VARCHAR),
                                 starttime,
                                 endtime,
                                 CAST(activityid AS VARCHAR),
                                 CAST(description AS VARCHAR));
END;
$$;

alter function add_activity(varchar, varchar, bigint, bigint, varchar, varchar) owner to kzpurfgw;

